
public class MeteoClient {

}
