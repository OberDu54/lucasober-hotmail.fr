package fr.ul.miage.meteo.json;

public class Result {

}
